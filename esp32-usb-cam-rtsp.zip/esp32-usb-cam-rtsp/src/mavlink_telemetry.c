/**
 * @file mavlink_telemetry.c
 * @brief MAVLink Telemetri Modülü implementasyonu
 *
 * Pixhawk <-> ESP32 <-> GCS köprüsü
 */

#include "mavlink_telemetry.h"
#include "mavlink_types.h"
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "freertos/queue.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "driver/uart.h"
#include "lwip/sockets.h"
#include "lwip/netdb.h"

static const char *TAG = "MAVLINK";

// CRC_EXTRA değerleri (yaygın mesajlar için)
static const struct
{
    uint32_t msgid;
    uint8_t crc_extra;
} crc_extra_table[] = {
    {0, 50},        // HEARTBEAT
    {1, 124},       // SYS_STATUS
    {2, 137},       // SYSTEM_TIME
    {4, 237},       // PING
    {24, 24},       // GPS_RAW_INT
    {30, 39},       // ATTITUDE
    {33, 104},      // GLOBAL_POSITION_INT
    {35, 244},      // RC_CHANNELS_RAW
    {36, 54},       // SERVO_OUTPUT_RAW
    {65, 118},      // RC_CHANNELS
    {74, 20},       // VFR_HUD
    {76, 152},      // COMMAND_LONG
    {77, 143},      // COMMAND_ACK
    {147, 154},     // BATTERY_STATUS
    {253, 83},      // STATUSTEXT
    {0xFFFFFFFF, 0} // End marker
};

// GCS istemci yapısı
typedef struct
{
    bool active;
    struct sockaddr_in addr;
    uint64_t last_seen;
    uint32_t messages_sent;
    uint32_t messages_received;
} gcs_client_internal_t;

// Modül durumu
static struct
{
    bool initialized;
    mavlink_state_t state;
    mavlink_config_t config;

    // UART
    QueueHandle_t uart_queue;

    // UDP
    int udp_socket;
    gcs_client_internal_t gcs_clients[MAVLINK_MAX_GCS_CLIENTS];
    SemaphoreHandle_t clients_mutex;

    // Parser
    mavlink_parser_t parser;

    // Heartbeat bilgisi
    mavlink_heartbeat_info_t heartbeat;
    SemaphoreHandle_t heartbeat_mutex;

    // İstatistikler
    mavlink_stats_t stats;
    uint64_t start_time;

    // Task handles
    TaskHandle_t uart_rx_task;
    TaskHandle_t udp_rx_task;
    bool tasks_running;
} s_mavlink = {0};

// Forward declarations
static void uart_rx_task(void *arg);
static void udp_rx_task(void *arg);
static void process_mavlink_message(const mavlink_message_t *msg, bool from_pixhawk);
static void forward_to_gcs(const uint8_t *data, size_t len);
static void forward_to_pixhawk(const uint8_t *data, size_t len);

// ============================================================================
// CRC Functions
// ============================================================================

void mavlink_crc_init(uint16_t *crc)
{
    *crc = 0xFFFF;
}

void mavlink_crc_accumulate(uint8_t byte, uint16_t *crc)
{
    uint8_t tmp = byte ^ (uint8_t)(*crc & 0xFF);
    tmp ^= (tmp << 4);
    *crc = (*crc >> 8) ^ ((uint16_t)tmp << 8) ^ ((uint16_t)tmp << 3) ^ ((uint16_t)tmp >> 4);
}

uint16_t mavlink_crc_calculate(const uint8_t *buffer, uint16_t length)
{
    uint16_t crc;
    mavlink_crc_init(&crc);
    while (length--)
    {
        mavlink_crc_accumulate(*buffer++, &crc);
    }
    return crc;
}

uint8_t mavlink_get_crc_extra(uint32_t msgid)
{
    for (int i = 0; crc_extra_table[i].msgid != 0xFFFFFFFF; i++)
    {
        if (crc_extra_table[i].msgid == msgid)
        {
            return crc_extra_table[i].crc_extra;
        }
    }
    return 0;
}

// ============================================================================
// Parser Functions
// ============================================================================

void mavlink_parser_init(mavlink_parser_t *parser)
{
    memset(parser, 0, sizeof(mavlink_parser_t));
    parser->state = MAVLINK_PARSE_STATE_IDLE;
}

mavlink_framing_t mavlink_parse_char(mavlink_parser_t *parser, uint8_t byte, mavlink_message_t *msg)
{
    switch (parser->state)
    {
    case MAVLINK_PARSE_STATE_IDLE:
        if (byte == MAVLINK_STX_V1 || byte == MAVLINK_STX_V2)
        {
            parser->msg.magic = byte;
            parser->packet_idx = 0;
            mavlink_crc_init(&parser->checksum);
            parser->state = MAVLINK_PARSE_STATE_GOT_STX;
        }
        break;

    case MAVLINK_PARSE_STATE_GOT_STX:
        parser->msg.len = byte;
        mavlink_crc_accumulate(byte, &parser->checksum);
        if (parser->msg.magic == MAVLINK_STX_V2)
        {
            parser->state = MAVLINK_PARSE_STATE_GOT_LENGTH;
        }
        else
        {
            parser->msg.incompat_flags = 0;
            parser->msg.compat_flags = 0;
            parser->state = MAVLINK_PARSE_STATE_GOT_COMPAT_FLAGS;
        }
        break;

    case MAVLINK_PARSE_STATE_GOT_LENGTH:
        parser->msg.incompat_flags = byte;
        mavlink_crc_accumulate(byte, &parser->checksum);
        parser->state = MAVLINK_PARSE_STATE_GOT_INCOMPAT_FLAGS;
        break;

    case MAVLINK_PARSE_STATE_GOT_INCOMPAT_FLAGS:
        parser->msg.compat_flags = byte;
        mavlink_crc_accumulate(byte, &parser->checksum);
        parser->state = MAVLINK_PARSE_STATE_GOT_COMPAT_FLAGS;
        break;

    case MAVLINK_PARSE_STATE_GOT_COMPAT_FLAGS:
        parser->msg.seq = byte;
        mavlink_crc_accumulate(byte, &parser->checksum);
        parser->state = MAVLINK_PARSE_STATE_GOT_SEQ;
        break;

    case MAVLINK_PARSE_STATE_GOT_SEQ:
        parser->msg.sysid = byte;
        mavlink_crc_accumulate(byte, &parser->checksum);
        parser->state = MAVLINK_PARSE_STATE_GOT_SYSID;
        break;

    case MAVLINK_PARSE_STATE_GOT_SYSID:
        parser->msg.compid = byte;
        mavlink_crc_accumulate(byte, &parser->checksum);
        if (parser->msg.magic == MAVLINK_STX_V2)
        {
            parser->state = MAVLINK_PARSE_STATE_GOT_COMPID;
        }
        else
        {
            parser->state = MAVLINK_PARSE_STATE_GOT_MSGID3;
        }
        break;

    case MAVLINK_PARSE_STATE_GOT_COMPID:
        parser->msg.msgid = byte;
        mavlink_crc_accumulate(byte, &parser->checksum);
        parser->state = MAVLINK_PARSE_STATE_GOT_MSGID1;
        break;

    case MAVLINK_PARSE_STATE_GOT_MSGID1:
        parser->msg.msgid |= ((uint32_t)byte << 8);
        mavlink_crc_accumulate(byte, &parser->checksum);
        parser->state = MAVLINK_PARSE_STATE_GOT_MSGID2;
        break;

    case MAVLINK_PARSE_STATE_GOT_MSGID2:
        parser->msg.msgid |= ((uint32_t)byte << 16);
        mavlink_crc_accumulate(byte, &parser->checksum);
        parser->state = MAVLINK_PARSE_STATE_GOT_MSGID3;
        break;

    case MAVLINK_PARSE_STATE_GOT_MSGID3:
        if (parser->msg.magic == MAVLINK_STX_V1)
        {
            parser->msg.msgid = byte;
            mavlink_crc_accumulate(byte, &parser->checksum);
        }
        parser->packet_idx = 0;
        if (parser->msg.len > 0)
        {
            if (parser->msg.magic == MAVLINK_STX_V1)
            {
                parser->state = MAVLINK_PARSE_STATE_GOT_PAYLOAD;
            }
            else
            {
                parser->msg.payload[parser->packet_idx++] = byte;
                mavlink_crc_accumulate(byte, &parser->checksum);
                if (parser->packet_idx >= parser->msg.len)
                {
                    parser->state = MAVLINK_PARSE_STATE_GOT_PAYLOAD;
                }
            }
        }
        else
        {
            parser->state = MAVLINK_PARSE_STATE_GOT_PAYLOAD;
        }
        break;

    case MAVLINK_PARSE_STATE_GOT_PAYLOAD:
        if (parser->packet_idx < parser->msg.len)
        {
            parser->msg.payload[parser->packet_idx++] = byte;
            mavlink_crc_accumulate(byte, &parser->checksum);
            if (parser->packet_idx >= parser->msg.len)
            {
                uint8_t crc_extra = mavlink_get_crc_extra(parser->msg.msgid);
                mavlink_crc_accumulate(crc_extra, &parser->checksum);
            }
        }
        else
        {
            parser->msg.checksum = byte;
            parser->state = MAVLINK_PARSE_STATE_GOT_CRC1;
        }
        break;

    case MAVLINK_PARSE_STATE_GOT_CRC1:
        parser->msg.checksum |= ((uint16_t)byte << 8);
        if (parser->msg.checksum == parser->checksum)
        {
            if (msg)
            {
                memcpy(msg, &parser->msg, sizeof(mavlink_message_t));
            }
            parser->state = MAVLINK_PARSE_STATE_IDLE;
            return MAVLINK_FRAMING_OK;
        }
        else
        {
            parser->state = MAVLINK_PARSE_STATE_IDLE;
            return MAVLINK_FRAMING_BAD_CRC;
        }
        break;

    default:
        parser->state = MAVLINK_PARSE_STATE_IDLE;
        break;
    }

    return MAVLINK_FRAMING_INCOMPLETE;
}

// ============================================================================
// GCS Client Management
// ============================================================================

static gcs_client_internal_t *find_gcs_client(const struct sockaddr_in *addr)
{
    for (int i = 0; i < MAVLINK_MAX_GCS_CLIENTS; i++)
    {
        if (s_mavlink.gcs_clients[i].active &&
            s_mavlink.gcs_clients[i].addr.sin_addr.s_addr == addr->sin_addr.s_addr &&
            s_mavlink.gcs_clients[i].addr.sin_port == addr->sin_port)
        {
            return &s_mavlink.gcs_clients[i];
        }
    }
    return NULL;
}

static gcs_client_internal_t *add_gcs_client(const struct sockaddr_in *addr)
{
    gcs_client_internal_t *client = find_gcs_client(addr);
    if (client)
    {
        client->last_seen = esp_timer_get_time() / 1000;
        return client;
    }

    for (int i = 0; i < MAVLINK_MAX_GCS_CLIENTS; i++)
    {
        if (!s_mavlink.gcs_clients[i].active)
        {
            s_mavlink.gcs_clients[i].active = true;
            memcpy(&s_mavlink.gcs_clients[i].addr, addr, sizeof(struct sockaddr_in));
            s_mavlink.gcs_clients[i].last_seen = esp_timer_get_time() / 1000;
            s_mavlink.gcs_clients[i].messages_sent = 0;
            s_mavlink.gcs_clients[i].messages_received = 0;

            s_mavlink.stats.gcs_clients++;

            ESP_LOGI(TAG, "GCS connected: %s:%d",
                     inet_ntoa(addr->sin_addr), ntohs(addr->sin_port));

            if (s_mavlink.config.on_gcs_connect)
            {
                s_mavlink.config.on_gcs_connect(addr->sin_addr.s_addr,
                                                ntohs(addr->sin_port),
                                                s_mavlink.config.callback_arg);
            }

            return &s_mavlink.gcs_clients[i];
        }
    }

    return NULL;
}

static void cleanup_stale_gcs_clients(void)
{
    uint64_t now = esp_timer_get_time() / 1000;
    const uint64_t timeout_ms = 30000;

    for (int i = 0; i < MAVLINK_MAX_GCS_CLIENTS; i++)
    {
        if (s_mavlink.gcs_clients[i].active)
        {
            if (now - s_mavlink.gcs_clients[i].last_seen > timeout_ms)
            {
                ESP_LOGI(TAG, "GCS timeout: %s:%d",
                         inet_ntoa(s_mavlink.gcs_clients[i].addr.sin_addr),
                         ntohs(s_mavlink.gcs_clients[i].addr.sin_port));

                if (s_mavlink.config.on_gcs_disconnect)
                {
                    s_mavlink.config.on_gcs_disconnect(
                        s_mavlink.gcs_clients[i].addr.sin_addr.s_addr,
                        ntohs(s_mavlink.gcs_clients[i].addr.sin_port),
                        s_mavlink.config.callback_arg);
                }

                s_mavlink.gcs_clients[i].active = false;
                if (s_mavlink.stats.gcs_clients > 0)
                {
                    s_mavlink.stats.gcs_clients--;
                }
            }
        }
    }
}

// ============================================================================
// Message Processing
// ============================================================================

static void process_mavlink_message(const mavlink_message_t *msg, bool from_pixhawk)
{
    s_mavlink.stats.mavlink_messages_rx++;

    if (msg->msgid == MAVLINK_MSG_ID_HEARTBEAT && from_pixhawk)
    {
        xSemaphoreTake(s_mavlink.heartbeat_mutex, portMAX_DELAY);

        mavlink_heartbeat_t *hb = (mavlink_heartbeat_t *)msg->payload;
        s_mavlink.heartbeat.system_id = msg->sysid;
        s_mavlink.heartbeat.component_id = msg->compid;
        s_mavlink.heartbeat.type = hb->type;
        s_mavlink.heartbeat.autopilot = hb->autopilot;
        s_mavlink.heartbeat.base_mode = hb->base_mode;
        s_mavlink.heartbeat.custom_mode = hb->custom_mode;
        s_mavlink.heartbeat.system_status = hb->system_status;
        s_mavlink.heartbeat.last_heartbeat_time = esp_timer_get_time() / 1000;

        s_mavlink.stats.pixhawk_system_id = msg->sysid;
        s_mavlink.stats.pixhawk_component_id = msg->compid;

        xSemaphoreGive(s_mavlink.heartbeat_mutex);

        if (s_mavlink.state != MAVLINK_STATE_PIXHAWK_CONNECTED &&
            s_mavlink.state != MAVLINK_STATE_GCS_CONNECTED)
        {
            s_mavlink.state = MAVLINK_STATE_PIXHAWK_CONNECTED;
            ESP_LOGI(TAG, "Pixhawk: SysID=%d Type=%d AP=%d",
                     msg->sysid, hb->type, hb->autopilot);
        }

        if (s_mavlink.config.on_heartbeat)
        {
            s_mavlink.config.on_heartbeat(&s_mavlink.heartbeat,
                                          s_mavlink.config.callback_arg);
        }
    }
}

static void forward_to_gcs(const uint8_t *data, size_t len)
{
    if (s_mavlink.udp_socket < 0)
        return;

    xSemaphoreTake(s_mavlink.clients_mutex, portMAX_DELAY);

    for (int i = 0; i < MAVLINK_MAX_GCS_CLIENTS; i++)
    {
        if (s_mavlink.gcs_clients[i].active)
        {
            int sent = sendto(s_mavlink.udp_socket, data, len, 0,
                              (struct sockaddr *)&s_mavlink.gcs_clients[i].addr,
                              sizeof(struct sockaddr_in));
            if (sent > 0)
            {
                s_mavlink.stats.udp_tx_bytes += sent;
                s_mavlink.gcs_clients[i].messages_sent++;
            }
        }
    }

    xSemaphoreGive(s_mavlink.clients_mutex);
}

static void forward_to_pixhawk(const uint8_t *data, size_t len)
{
    int written = uart_write_bytes(s_mavlink.config.uart_num, data, len);
    if (written > 0)
    {
        s_mavlink.stats.uart_tx_bytes += written;
        s_mavlink.stats.mavlink_messages_tx++;
    }
}

// ============================================================================
// Tasks - HEAP BUFFERS (stack overflow fix)
// ============================================================================

static void uart_rx_task(void *arg)
{

    // Heap'te buffer ayır (stack overflow önleme)
    uint8_t *buffer = heap_caps_malloc(512, MALLOC_CAP_8BIT);
    uint8_t *raw_packet = heap_caps_malloc(MAVLINK_MAX_PACKET_LEN, MALLOC_CAP_8BIT);

    if (!buffer || !raw_packet)
    {
        ESP_LOGE(TAG, "Failed to allocate UART buffers");
        if (buffer)
            free(buffer);
        if (raw_packet)
            free(raw_packet);
        vTaskDelete(NULL);
        return;
    }

    size_t raw_packet_len = 0;
    mavlink_message_t msg;
    uint32_t last_cleanup = 0;

    while (s_mavlink.tasks_running)
    {
        int len = uart_read_bytes(s_mavlink.config.uart_num, buffer,
                                  512, pdMS_TO_TICKS(10));

        if (len > 0)
        {
            s_mavlink.stats.uart_rx_bytes += len;

            for (int i = 0; i < len; i++)
            {
                if (raw_packet_len < MAVLINK_MAX_PACKET_LEN)
                {
                    raw_packet[raw_packet_len++] = buffer[i];
                }

                mavlink_framing_t result = mavlink_parse_char(&s_mavlink.parser,
                                                              buffer[i], &msg);

                if (result == MAVLINK_FRAMING_OK)
                {
                    process_mavlink_message(&msg, true);
                    forward_to_gcs(raw_packet, raw_packet_len);
                    raw_packet_len = 0;
                }
                else if (result == MAVLINK_FRAMING_BAD_CRC)
                {
                    s_mavlink.stats.parse_errors++;
                    raw_packet_len = 0;
                }
                else if (s_mavlink.parser.state == MAVLINK_PARSE_STATE_IDLE)
                {
                    raw_packet_len = 0;
                }
            }
        }

        uint32_t now = xTaskGetTickCount();
        if (now - last_cleanup > pdMS_TO_TICKS(5000))
        {
            cleanup_stale_gcs_clients();
            last_cleanup = now;
        }
    }

    free(buffer);
    free(raw_packet);

    vTaskDelete(NULL);
}

static void udp_rx_task(void *arg)
{
    // Heap'te buffer ayır
    uint8_t *buffer = heap_caps_malloc(512, MALLOC_CAP_8BIT);
    if (!buffer)
    {
        ESP_LOGE(TAG, "Failed to allocate UDP buffer");
        vTaskDelete(NULL);
        return;
    }

    struct sockaddr_in src_addr;
    socklen_t src_len;

    // Socket timeout ayarla (select yerine)
    struct timeval tv;
    tv.tv_sec = 0;
    tv.tv_usec = 50000; // 50ms timeout
    setsockopt(s_mavlink.udp_socket, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    while (s_mavlink.tasks_running)
    {
        src_len = sizeof(src_addr);
        int len = recvfrom(s_mavlink.udp_socket, buffer, 512, 0,
                           (struct sockaddr *)&src_addr, &src_len);

        if (len > 0)
        {
            s_mavlink.stats.udp_rx_bytes += len;

            xSemaphoreTake(s_mavlink.clients_mutex, portMAX_DELAY);
            gcs_client_internal_t *client = add_gcs_client(&src_addr);
            if (client)
            {
                client->messages_received++;
                if (s_mavlink.state == MAVLINK_STATE_PIXHAWK_CONNECTED)
                {
                    s_mavlink.state = MAVLINK_STATE_GCS_CONNECTED;
                }
            }
            xSemaphoreGive(s_mavlink.clients_mutex);

            forward_to_pixhawk(buffer, len);
        }

        // Her zaman yield yap - watchdog için kritik!
        vTaskDelay(pdMS_TO_TICKS(1));
    }

    free(buffer);

    vTaskDelete(NULL);
}

// ============================================================================
// Public API
// ============================================================================

esp_err_t mavlink_telemetry_init(const mavlink_config_t *config)
{
    if (s_mavlink.initialized)
    {
        ESP_LOGW(TAG, "Already initialized");
        return ESP_OK;
    }

    esp_err_t ret;

    if (config)
    {
        memcpy(&s_mavlink.config, config, sizeof(mavlink_config_t));
    }
    else
    {
        s_mavlink.config.uart_num = MAVLINK_UART_NUM;
        s_mavlink.config.uart_tx_pin = MAVLINK_UART_TX_PIN;
        s_mavlink.config.uart_rx_pin = MAVLINK_UART_RX_PIN;
        s_mavlink.config.uart_baud = MAVLINK_UART_BAUD;
        s_mavlink.config.udp_port = MAVLINK_UDP_PORT;
    }

    s_mavlink.clients_mutex = xSemaphoreCreateMutex();
    s_mavlink.heartbeat_mutex = xSemaphoreCreateMutex();
    if (!s_mavlink.clients_mutex || !s_mavlink.heartbeat_mutex)
    {
        ESP_LOGE(TAG, "Failed to create mutexes");
        return ESP_ERR_NO_MEM;
    }

    uart_config_t uart_config = {
        .baud_rate = s_mavlink.config.uart_baud,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };

    ret = uart_driver_install(s_mavlink.config.uart_num,
                              1024, 1024,
                              20, &s_mavlink.uart_queue, 0);
    if (ret != ESP_OK)
    {
        ESP_LOGE(TAG, "uart_driver_install failed: %s", esp_err_to_name(ret));
        return ret;
    }

    ret = uart_param_config(s_mavlink.config.uart_num, &uart_config);
    if (ret != ESP_OK)
    {
        ESP_LOGE(TAG, "uart_param_config failed: %s", esp_err_to_name(ret));
        uart_driver_delete(s_mavlink.config.uart_num);
        return ret;
    }

    ret = uart_set_pin(s_mavlink.config.uart_num,
                       s_mavlink.config.uart_tx_pin,
                       s_mavlink.config.uart_rx_pin,
                       UART_PIN_NO_CHANGE,
                       UART_PIN_NO_CHANGE);
    if (ret != ESP_OK)
    {
        ESP_LOGE(TAG, "uart_set_pin failed: %s", esp_err_to_name(ret));
        uart_driver_delete(s_mavlink.config.uart_num);
        return ret;
    }

    mavlink_parser_init(&s_mavlink.parser);
    memset(s_mavlink.gcs_clients, 0, sizeof(s_mavlink.gcs_clients));

    s_mavlink.initialized = true;
    s_mavlink.state = MAVLINK_STATE_STOPPED;

    return ESP_OK;
}

esp_err_t mavlink_telemetry_deinit(void)
{
    if (!s_mavlink.initialized)
    {
        return ESP_ERR_INVALID_STATE;
    }

    mavlink_telemetry_stop();
    uart_driver_delete(s_mavlink.config.uart_num);
    vSemaphoreDelete(s_mavlink.clients_mutex);
    vSemaphoreDelete(s_mavlink.heartbeat_mutex);

    s_mavlink.initialized = false;

    return ESP_OK;
}

esp_err_t mavlink_telemetry_start(void)
{
    if (!s_mavlink.initialized)
    {
        return ESP_ERR_INVALID_STATE;
    }

    if (s_mavlink.state != MAVLINK_STATE_STOPPED)
    {
        return ESP_OK;
    }

    s_mavlink.udp_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (s_mavlink.udp_socket < 0)
    {
        ESP_LOGE(TAG, "Failed to create UDP socket");
        return ESP_FAIL;
    }

    struct sockaddr_in bind_addr;
    memset(&bind_addr, 0, sizeof(bind_addr));
    bind_addr.sin_family = AF_INET;
    bind_addr.sin_addr.s_addr = INADDR_ANY;
    bind_addr.sin_port = htons(s_mavlink.config.udp_port);

    if (bind(s_mavlink.udp_socket, (struct sockaddr *)&bind_addr,
             sizeof(bind_addr)) < 0)
    {
        ESP_LOGE(TAG, "UDP bind failed: %d", errno);
        close(s_mavlink.udp_socket);
        return ESP_FAIL;
    }

    s_mavlink.tasks_running = true;
    s_mavlink.start_time = esp_timer_get_time() / 1000;

    // Task stack boyutları küçültüldü - buffer'lar heap'te
    xTaskCreatePinnedToCore(uart_rx_task, "mav_uart", 3072, NULL, 6,
                            &s_mavlink.uart_rx_task, 0);
    xTaskCreatePinnedToCore(udp_rx_task, "mav_udp", 3072, NULL, 5,
                            &s_mavlink.udp_rx_task, 1);

    s_mavlink.state = MAVLINK_STATE_RUNNING;

    return ESP_OK;
}

esp_err_t mavlink_telemetry_stop(void)
{
    if (!s_mavlink.initialized || s_mavlink.state == MAVLINK_STATE_STOPPED)
    {
        return ESP_ERR_INVALID_STATE;
    }

    s_mavlink.tasks_running = false;
    vTaskDelay(pdMS_TO_TICKS(200));

    if (s_mavlink.udp_socket >= 0)
    {
        close(s_mavlink.udp_socket);
        s_mavlink.udp_socket = -1;
    }

    s_mavlink.state = MAVLINK_STATE_STOPPED;

    return ESP_OK;
}

mavlink_state_t mavlink_telemetry_get_state(void)
{
    return s_mavlink.state;
}

esp_err_t mavlink_telemetry_get_stats(mavlink_stats_t *stats)
{
    if (!stats)
    {
        return ESP_ERR_INVALID_ARG;
    }

    memcpy(stats, &s_mavlink.stats, sizeof(mavlink_stats_t));

    if (s_mavlink.start_time > 0)
    {
        stats->uptime_ms = (esp_timer_get_time() / 1000) - s_mavlink.start_time;
    }

    return ESP_OK;
}

esp_err_t mavlink_telemetry_get_heartbeat(mavlink_heartbeat_info_t *info)
{
    if (!info)
    {
        return ESP_ERR_INVALID_ARG;
    }

    xSemaphoreTake(s_mavlink.heartbeat_mutex, portMAX_DELAY);
    memcpy(info, &s_mavlink.heartbeat, sizeof(mavlink_heartbeat_info_t));
    xSemaphoreGive(s_mavlink.heartbeat_mutex);

    return ESP_OK;
}

uint8_t mavlink_telemetry_get_gcs_clients(mavlink_gcs_client_t *clients, uint8_t max_clients)
{
    if (!clients || max_clients == 0)
    {
        return 0;
    }

    uint8_t count = 0;

    xSemaphoreTake(s_mavlink.clients_mutex, portMAX_DELAY);

    for (int i = 0; i < MAVLINK_MAX_GCS_CLIENTS && count < max_clients; i++)
    {
        if (s_mavlink.gcs_clients[i].active)
        {
            clients[count].ip_addr = s_mavlink.gcs_clients[i].addr.sin_addr.s_addr;
            clients[count].port = ntohs(s_mavlink.gcs_clients[i].addr.sin_port);
            clients[count].last_seen = s_mavlink.gcs_clients[i].last_seen;
            clients[count].messages_sent = s_mavlink.gcs_clients[i].messages_sent;
            clients[count].messages_received = s_mavlink.gcs_clients[i].messages_received;
            count++;
        }
    }

    xSemaphoreGive(s_mavlink.clients_mutex);

    return count;
}

bool mavlink_telemetry_is_pixhawk_connected(void)
{
    if (!s_mavlink.initialized)
        return false;

    xSemaphoreTake(s_mavlink.heartbeat_mutex, portMAX_DELAY);
    uint64_t last_hb = s_mavlink.heartbeat.last_heartbeat_time;
    xSemaphoreGive(s_mavlink.heartbeat_mutex);

    uint64_t now = esp_timer_get_time() / 1000;
    return (last_hb > 0 && (now - last_hb) < 3000);
}

bool mavlink_telemetry_is_gcs_connected(void)
{
    return s_mavlink.stats.gcs_clients > 0;
}

esp_err_t mavlink_telemetry_send_to_pixhawk(const uint8_t *data, size_t len)
{
    if (!data || len == 0)
    {
        return ESP_ERR_INVALID_ARG;
    }
    forward_to_pixhawk(data, len);
    return ESP_OK;
}

esp_err_t mavlink_telemetry_send_to_gcs(const uint8_t *data, size_t len)
{
    if (!data || len == 0)
    {
        return ESP_ERR_INVALID_ARG;
    }
    forward_to_gcs(data, len);
    return ESP_OK;
}