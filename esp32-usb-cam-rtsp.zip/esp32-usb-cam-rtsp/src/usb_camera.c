/**
 * @file usb_camera.c
 * @brief USB UVC Kamera - Gerçek implementasyon
 *
 * ESP32-S3 USB Host API ile UVC kamera desteği.
 * Component manager olmadan, direkt ESP-IDF USB Host kullanır.
 */

#include "usb_camera.h"
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "freertos/queue.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "usb/usb_host.h"
#include "usb/usb_types_ch9.h"

static const char *TAG = "USB_CAM";

// UVC Subclass codes
#define UVC_SC_VIDEOCONTROL 0x01
#define UVC_SC_VIDEOSTREAMING 0x02

// Frame buffer - minimal (no PSRAM)
#define FRAME_BUFFER_SIZE (25 * 1024) // 25KB per buffer (VGA MJPEG ~10-20KB)
#define FRAME_BUFFER_COUNT 1          // Single buffer to save RAM
#define USB_TRANSFER_SIZE (4 * 1024)

// Module state
static struct
{
    bool initialized;
    bool running;
    usb_cam_state_t state;
    usb_cam_config_t config;

    // USB handles
    usb_host_client_handle_t client_hdl;
    usb_device_handle_t dev_hdl;
    uint8_t dev_addr;

    // Interface info
    uint8_t ctrl_intf;
    uint8_t stream_intf;
    uint8_t stream_ep;
    uint16_t stream_mps;
    uint8_t stream_alt;

    // Frame buffers
    uint8_t *frame_buffers[FRAME_BUFFER_COUNT];
    size_t frame_sizes[FRAME_BUFFER_COUNT];
    uint8_t write_idx;
    uint8_t read_idx;
    SemaphoreHandle_t frame_mutex;

    // Current frame assembly
    uint8_t *current_frame;
    size_t current_size;
    uint32_t frame_sequence;

    // USB transfer
    usb_transfer_t *xfer_in;

    // Stats
    uint32_t total_frames;
    uint64_t fps_start;
    float current_fps;

    // Tasks
    TaskHandle_t host_task;
    TaskHandle_t stream_task;
} s_cam = {0};

// Forward declarations
static void usb_host_task(void *arg);
static void client_event_cb(const usb_host_client_event_msg_t *msg, void *arg);
static esp_err_t open_device(uint8_t addr);
static void close_device(void);
static esp_err_t start_streaming(void);
static void stop_streaming(void);
static void transfer_cb(usb_transfer_t *transfer);

esp_err_t usb_camera_init(const usb_cam_config_t *config)
{
    if (s_cam.initialized)
    {
        return ESP_OK;
    }

    ESP_LOGI(TAG, "Initializing USB Camera...");

    // Config
    if (config)
    {
        memcpy(&s_cam.config, config, sizeof(usb_cam_config_t));
    }
    else
    {
        s_cam.config.width = CAM_FRAME_WIDTH;
        s_cam.config.height = CAM_FRAME_HEIGHT;
        s_cam.config.fps = CAM_FPS;
        s_cam.config.format = USB_CAM_FORMAT_MJPEG;
    }

    // Frame mutex
    s_cam.frame_mutex = xSemaphoreCreateMutex();
    if (!s_cam.frame_mutex)
    {
        return ESP_ERR_NO_MEM;
    }

    // Allocate frame buffers (internal RAM only - no PSRAM)
    for (int i = 0; i < FRAME_BUFFER_COUNT; i++)
    {
        s_cam.frame_buffers[i] = heap_caps_malloc(FRAME_BUFFER_SIZE, MALLOC_CAP_8BIT | MALLOC_CAP_INTERNAL);
        if (!s_cam.frame_buffers[i])
        {
            ESP_LOGE(TAG, "Failed to allocate frame buffer %d", i);
            for (int j = 0; j < i; j++)
            {
                free(s_cam.frame_buffers[j]);
            }
            vSemaphoreDelete(s_cam.frame_mutex);
            return ESP_ERR_NO_MEM;
        }
        s_cam.frame_sizes[i] = 0;
    }

    // Current frame buffer for assembly
    s_cam.current_frame = heap_caps_malloc(FRAME_BUFFER_SIZE, MALLOC_CAP_8BIT | MALLOC_CAP_INTERNAL);
    if (!s_cam.current_frame)
    {
        for (int i = 0; i < FRAME_BUFFER_COUNT; i++)
        {
            free(s_cam.frame_buffers[i]);
        }
        vSemaphoreDelete(s_cam.frame_mutex);
        return ESP_ERR_NO_MEM;
    }

    // Install USB Host
    usb_host_config_t host_config = {
        .skip_phy_setup = false,
        .intr_flags = ESP_INTR_FLAG_LEVEL1,
    };
    esp_err_t ret = usb_host_install(&host_config);
    if (ret != ESP_OK)
    {
        ESP_LOGE(TAG, "USB Host install failed: %s", esp_err_to_name(ret));
        free(s_cam.current_frame);
        for (int i = 0; i < FRAME_BUFFER_COUNT; i++)
        {
            free(s_cam.frame_buffers[i]);
        }
        vSemaphoreDelete(s_cam.frame_mutex);
        return ret;
    }

    // Register client
    usb_host_client_config_t client_config = {
        .is_synchronous = false,
        .max_num_event_msg = 5,
        .async = {
            .client_event_callback = client_event_cb,
            .callback_arg = NULL,
        },
    };
    ret = usb_host_client_register(&client_config, &s_cam.client_hdl);
    if (ret != ESP_OK)
    {
        ESP_LOGE(TAG, "Client register failed: %s", esp_err_to_name(ret));
        usb_host_uninstall();
        free(s_cam.current_frame);
        for (int i = 0; i < FRAME_BUFFER_COUNT; i++)
        {
            free(s_cam.frame_buffers[i]);
        }
        vSemaphoreDelete(s_cam.frame_mutex);
        return ret;
    }

    s_cam.initialized = true;
    s_cam.state = USB_CAM_STATE_DISCONNECTED;
    s_cam.fps_start = esp_timer_get_time();

    ESP_LOGI(TAG, "USB Camera initialized, waiting for device...");

    return ESP_OK;
}

esp_err_t usb_camera_deinit(void)
{
    if (!s_cam.initialized)
    {
        return ESP_OK;
    }

    usb_camera_stop();

    close_device();

    usb_host_client_deregister(s_cam.client_hdl);
    usb_host_uninstall();

    free(s_cam.current_frame);
    for (int i = 0; i < FRAME_BUFFER_COUNT; i++)
    {
        free(s_cam.frame_buffers[i]);
    }
    vSemaphoreDelete(s_cam.frame_mutex);

    s_cam.initialized = false;
    return ESP_OK;
}

esp_err_t usb_camera_start(void)
{
    if (!s_cam.initialized)
    {
        return ESP_ERR_INVALID_STATE;
    }

    if (s_cam.running)
    {
        return ESP_OK;
    }

    s_cam.running = true;

    // Start USB host task
    xTaskCreatePinnedToCore(usb_host_task, "usb_host", 4096, NULL, 3, &s_cam.host_task, 0);

    return ESP_OK;
}

esp_err_t usb_camera_stop(void)
{
    if (!s_cam.running)
    {
        return ESP_OK;
    }

    s_cam.running = false;

    stop_streaming();

    if (s_cam.host_task)
    {
        vTaskDelay(pdMS_TO_TICKS(100));
        s_cam.host_task = NULL;
    }

    return ESP_OK;
}

usb_cam_state_t usb_camera_get_state(void)
{
    return s_cam.state;
}

float usb_camera_get_fps(void)
{
    return s_cam.current_fps;
}

esp_err_t usb_camera_get_info(usb_cam_info_t *info)
{
    if (!info)
        return ESP_ERR_INVALID_ARG;
    memset(info, 0, sizeof(usb_cam_info_t));
    return ESP_OK;
}

esp_err_t usb_camera_get_frame(usb_cam_frame_t *frame, uint32_t timeout_ms)
{
    return ESP_ERR_NOT_SUPPORTED;
}

void usb_camera_release_frame(usb_cam_frame_t *frame)
{
    (void)frame;
}

esp_err_t usb_camera_set_param(uint32_t param, int32_t value)
{
    return ESP_ERR_NOT_SUPPORTED;
}

// ==================== Internal functions ====================

static void client_event_cb(const usb_host_client_event_msg_t *msg, void *arg)
{
    ESP_LOGI(TAG, "USB client event: %d", msg->event);

    switch (msg->event)
    {
    case USB_HOST_CLIENT_EVENT_NEW_DEV:
        ESP_LOGI(TAG, ">>> New USB device detected! addr=%d", msg->new_dev.address);
        if (s_cam.state == USB_CAM_STATE_DISCONNECTED)
        {
            open_device(msg->new_dev.address);
        }
        break;

    case USB_HOST_CLIENT_EVENT_DEV_GONE:
        ESP_LOGW(TAG, ">>> USB device removed!");
        if (s_cam.state != USB_CAM_STATE_DISCONNECTED)
        {
            stop_streaming();
            close_device();
            s_cam.state = USB_CAM_STATE_DISCONNECTED;
            if (s_cam.config.state_callback)
            {
                s_cam.config.state_callback(USB_CAM_STATE_DISCONNECTED, s_cam.config.callback_arg);
            }
        }
        break;

    default:
        ESP_LOGI(TAG, "Unknown USB event: %d", msg->event);
        break;
    }
}

static void usb_host_task(void *arg)
{
    ESP_LOGI(TAG, "USB Host task on CPU%d", xPortGetCoreID());

    uint32_t loop_count = 0;
    while (s_cam.running)
    {
        uint32_t event_flags = 0;
        esp_err_t ret = usb_host_lib_handle_events(pdMS_TO_TICKS(10), &event_flags);

        if (ret == ESP_OK && event_flags)
        {
            ESP_LOGI(TAG, "USB lib event: 0x%lx", (unsigned long)event_flags);
        }

        usb_host_client_handle_events(s_cam.client_hdl, pdMS_TO_TICKS(10));

        // Her 10 saniyede bir durum bildir
        loop_count++;
        if (loop_count % 500 == 0)
        {
            ESP_LOGI(TAG, "USB Host running... state=%d", s_cam.state);
        }

        vTaskDelay(1); // Yield to other tasks
    }

    vTaskDelete(NULL);
}

static esp_err_t open_device(uint8_t addr)
{
    esp_err_t ret;

    ret = usb_host_device_open(s_cam.client_hdl, addr, &s_cam.dev_hdl);
    if (ret != ESP_OK)
    {
        ESP_LOGE(TAG, "Device open failed: %s", esp_err_to_name(ret));
        return ret;
    }
    s_cam.dev_addr = addr;

    // Get device descriptor
    const usb_device_desc_t *dev_desc;
    ret = usb_host_get_device_descriptor(s_cam.dev_hdl, &dev_desc);
    if (ret != ESP_OK)
    {
        usb_host_device_close(s_cam.client_hdl, s_cam.dev_hdl);
        return ret;
    }

    ESP_LOGI(TAG, "Device: VID=0x%04X PID=0x%04X", dev_desc->idVendor, dev_desc->idProduct);

    // Get config descriptor
    const usb_config_desc_t *config_desc;
    ret = usb_host_get_active_config_descriptor(s_cam.dev_hdl, &config_desc);
    if (ret != ESP_OK)
    {
        usb_host_device_close(s_cam.client_hdl, s_cam.dev_hdl);
        return ret;
    }

    // Find UVC interfaces
    bool found_ctrl = false;
    bool found_stream = false;

    const uint8_t *p = (const uint8_t *)config_desc;
    const uint8_t *end = p + config_desc->wTotalLength;

    while (p < end)
    {
        const usb_intf_desc_t *intf = (const usb_intf_desc_t *)p;

        if (intf->bDescriptorType == USB_B_DESCRIPTOR_TYPE_INTERFACE)
        {
            if (intf->bInterfaceClass == USB_CLASS_VIDEO)
            {
                if (intf->bInterfaceSubClass == UVC_SC_VIDEOCONTROL)
                {
                    s_cam.ctrl_intf = intf->bInterfaceNumber;
                    found_ctrl = true;
                    ESP_LOGI(TAG, "Found VideoControl interface: %d", intf->bInterfaceNumber);
                }
                else if (intf->bInterfaceSubClass == UVC_SC_VIDEOSTREAMING)
                {
                    if (intf->bAlternateSetting > 0 && intf->bNumEndpoints > 0)
                    {
                        s_cam.stream_intf = intf->bInterfaceNumber;
                        s_cam.stream_alt = intf->bAlternateSetting;
                        found_stream = true;

                        // Find endpoint
                        const uint8_t *ep_p = p + intf->bLength;
                        while (ep_p < end)
                        {
                            const usb_ep_desc_t *ep = (const usb_ep_desc_t *)ep_p;
                            if (ep->bDescriptorType == USB_B_DESCRIPTOR_TYPE_ENDPOINT)
                            {
                                if ((ep->bmAttributes & 0x03) == USB_TRANSFER_TYPE_ISOCHRONOUS &&
                                    (ep->bEndpointAddress & 0x80))
                                {
                                    s_cam.stream_ep = ep->bEndpointAddress;
                                    s_cam.stream_mps = ep->wMaxPacketSize & 0x7FF;
                                    ESP_LOGI(TAG, "Found streaming EP: 0x%02X, MPS=%d, alt=%d",
                                             s_cam.stream_ep, s_cam.stream_mps, s_cam.stream_alt);
                                    break;
                                }
                            }
                            ep_p += ep->bLength;
                            if (ep->bLength == 0)
                                break;
                        }
                    }
                }
            }
        }
        p += intf->bLength;
        if (intf->bLength == 0)
            break;
    }

    if (!found_ctrl || !found_stream)
    {
        ESP_LOGW(TAG, "Not a UVC camera (ctrl=%d, stream=%d)", found_ctrl, found_stream);
        usb_host_device_close(s_cam.client_hdl, s_cam.dev_hdl);
        return ESP_ERR_NOT_FOUND;
    }

    // Claim interfaces
    ret = usb_host_interface_claim(s_cam.client_hdl, s_cam.dev_hdl, s_cam.ctrl_intf, 0);
    if (ret != ESP_OK)
    {
        ESP_LOGE(TAG, "Claim ctrl interface failed");
        usb_host_device_close(s_cam.client_hdl, s_cam.dev_hdl);
        return ret;
    }

    ret = usb_host_interface_claim(s_cam.client_hdl, s_cam.dev_hdl, s_cam.stream_intf, 0);
    if (ret != ESP_OK)
    {
        ESP_LOGE(TAG, "Claim stream interface failed");
        usb_host_interface_release(s_cam.client_hdl, s_cam.dev_hdl, s_cam.ctrl_intf);
        usb_host_device_close(s_cam.client_hdl, s_cam.dev_hdl);
        return ret;
    }

    s_cam.state = USB_CAM_STATE_CONNECTED;
    ESP_LOGI(TAG, "UVC Camera connected!");

    if (s_cam.config.state_callback)
    {
        s_cam.config.state_callback(USB_CAM_STATE_CONNECTED, s_cam.config.callback_arg);
    }

    // Start streaming
    start_streaming();

    return ESP_OK;
}

static void close_device(void)
{
    if (s_cam.dev_hdl)
    {
        usb_host_interface_release(s_cam.client_hdl, s_cam.dev_hdl, s_cam.stream_intf);
        usb_host_interface_release(s_cam.client_hdl, s_cam.dev_hdl, s_cam.ctrl_intf);
        usb_host_device_close(s_cam.client_hdl, s_cam.dev_hdl);
        s_cam.dev_hdl = NULL;
    }
}

static void transfer_cb(usb_transfer_t *transfer)
{
    if (transfer->status != USB_TRANSFER_STATUS_COMPLETED)
    {
        // Resubmit
        if (s_cam.state == USB_CAM_STATE_STREAMING)
        {
            usb_host_transfer_submit(transfer);
        }
        return;
    }

    // Process isochronous packets
    int num_packets = transfer->num_isoc_packets;
    uint8_t *data = transfer->data_buffer;

    for (int i = 0; i < num_packets; i++)
    {
        int len = transfer->isoc_packet_desc[i].actual_num_bytes;
        int offset = 0;

        // Calculate offset for this packet
        for (int j = 0; j < i; j++)
        {
            offset += transfer->isoc_packet_desc[j].num_bytes;
        }

        if (len < 2)
            continue;

        uint8_t *pkt = data + offset;
        uint8_t header_len = pkt[0];
        uint8_t header_flags = pkt[1];

        // Validate header
        if (header_len < 2 || header_len > 12 || header_len > len)
        {
            continue;
        }

        uint8_t *payload = pkt + header_len;
        int payload_len = len - header_len;

        // Append payload to current frame
        if (payload_len > 0 && s_cam.current_size + payload_len <= FRAME_BUFFER_SIZE)
        {
            memcpy(s_cam.current_frame + s_cam.current_size, payload, payload_len);
            s_cam.current_size += payload_len;
        }

        // End of frame? (EOF bit set)
        if (header_flags & 0x02)
        {
            // Only process if we have a reasonable frame size (> 1KB for MJPEG)
            if (s_cam.current_size > 1000)
            {
                // Copy to frame buffer
                xSemaphoreTake(s_cam.frame_mutex, portMAX_DELAY);

                memcpy(s_cam.frame_buffers[s_cam.write_idx], s_cam.current_frame, s_cam.current_size);
                s_cam.frame_sizes[s_cam.write_idx] = s_cam.current_size;

                uint8_t idx = s_cam.write_idx;
                size_t frame_size = s_cam.current_size;
                s_cam.write_idx = (s_cam.write_idx + 1) % FRAME_BUFFER_COUNT;

                xSemaphoreGive(s_cam.frame_mutex);

                s_cam.frame_sequence++;
                s_cam.total_frames++;

                // FPS calculation
                uint64_t now = esp_timer_get_time();
                if (now - s_cam.fps_start >= 1000000)
                {
                    s_cam.current_fps = (float)s_cam.total_frames * 1000000.0f / (float)(now - s_cam.fps_start);
                    s_cam.total_frames = 0;
                    s_cam.fps_start = now;
                }

                // Callback
                if (s_cam.config.frame_callback)
                {
                    usb_cam_frame_t frame = {
                        .data = s_cam.frame_buffers[idx],
                        .size = frame_size,
                        .capacity = FRAME_BUFFER_SIZE,
                        .width = s_cam.config.width,
                        .height = s_cam.config.height,
                        .format = USB_CAM_FORMAT_MJPEG,
                        .timestamp = esp_timer_get_time(),
                        .sequence = s_cam.frame_sequence,
                    };
                    s_cam.config.frame_callback(&frame, s_cam.config.callback_arg);
                }

                // Log
                if (s_cam.frame_sequence == 1)
                {
                    ESP_LOGI(TAG, "First frame: %u bytes", (unsigned)frame_size);
                }
                else if (s_cam.frame_sequence % 30 == 0)
                {
                    ESP_LOGI(TAG, "Frame #%lu: %uB %.1ffps",
                             (unsigned long)s_cam.frame_sequence,
                             (unsigned)frame_size,
                             s_cam.current_fps);
                }
            }
            // Reset for next frame
            s_cam.current_size = 0;
        }
    }

    // Resubmit transfer
    if (s_cam.state == USB_CAM_STATE_STREAMING)
    {
        usb_host_transfer_submit(transfer);
    }
}

static esp_err_t start_streaming(void)
{
    esp_err_t ret;

    // Set alternate setting for streaming
    ret = usb_host_interface_claim(s_cam.client_hdl, s_cam.dev_hdl,
                                   s_cam.stream_intf, s_cam.stream_alt);
    if (ret != ESP_OK)
    {
        ESP_LOGE(TAG, "Set alt setting failed: %s", esp_err_to_name(ret));
        return ret;
    }

    // Allocate transfer
    int num_packets = 8;
    int packet_size = s_cam.stream_mps;
    int total_size = num_packets * packet_size;

    ret = usb_host_transfer_alloc(total_size, num_packets, &s_cam.xfer_in);
    if (ret != ESP_OK)
    {
        ESP_LOGE(TAG, "Transfer alloc failed");
        return ret;
    }

    s_cam.xfer_in->device_handle = s_cam.dev_hdl;
    s_cam.xfer_in->bEndpointAddress = s_cam.stream_ep;
    s_cam.xfer_in->callback = transfer_cb;
    s_cam.xfer_in->context = NULL;
    s_cam.xfer_in->num_bytes = total_size;
    // num_isoc_packets is set by usb_host_transfer_alloc

    for (int i = 0; i < num_packets; i++)
    {
        s_cam.xfer_in->isoc_packet_desc[i].num_bytes = packet_size;
    }

    ret = usb_host_transfer_submit(s_cam.xfer_in);
    if (ret != ESP_OK)
    {
        ESP_LOGE(TAG, "Transfer submit failed: %s", esp_err_to_name(ret));
        usb_host_transfer_free(s_cam.xfer_in);
        s_cam.xfer_in = NULL;
        return ret;
    }

    s_cam.state = USB_CAM_STATE_STREAMING;
    s_cam.current_size = 0;
    s_cam.frame_sequence = 0;
    s_cam.total_frames = 0;
    s_cam.fps_start = esp_timer_get_time();

    ESP_LOGI(TAG, "Streaming started!");

    if (s_cam.config.state_callback)
    {
        s_cam.config.state_callback(USB_CAM_STATE_STREAMING, s_cam.config.callback_arg);
    }

    return ESP_OK;
}

static void stop_streaming(void)
{
    if (s_cam.state != USB_CAM_STATE_STREAMING)
    {
        return;
    }

    s_cam.state = USB_CAM_STATE_CONNECTED;

    if (s_cam.xfer_in)
    {
        usb_host_transfer_free(s_cam.xfer_in);
        s_cam.xfer_in = NULL;
    }

    // Reset to alt setting 0
    usb_host_interface_claim(s_cam.client_hdl, s_cam.dev_hdl, s_cam.stream_intf, 0);
}