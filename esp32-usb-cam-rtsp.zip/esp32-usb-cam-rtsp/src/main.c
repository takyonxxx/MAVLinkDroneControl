/**
 * @file main.c
 * @brief ESP32-S3 USB Camera RTSP Streamer + MAVLink Telemetry
 *
 * USB Camera: CPU0
 * WiFi/RTSP/MAVLink: CPU1
 */

#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "esp_system.h"
#include "esp_log.h"
#include "nvs_flash.h"

#include "wifi_ap.h"
#include "mavlink_telemetry.h"
#include "rtsp_server.h"
#include "usb_camera.h"

static const char *TAG = "MAIN";

// Frame queue - kamera -> RTSP
static QueueHandle_t s_frame_queue = NULL;
#define FRAME_QUEUE_SIZE 2

// Frame data for queue
typedef struct
{
    uint8_t *data;
    size_t size;
    uint32_t width;
    uint32_t height;
    uint32_t sequence;
} frame_msg_t;

// Frame buffer for queue (static allocation)
static uint8_t s_queue_buffer[25 * 1024];
static SemaphoreHandle_t s_queue_mutex = NULL;

// Kamera frame callback - queue'ya gönder
static void camera_frame_callback(usb_cam_frame_t *frame, void *arg)
{
    if (!frame || frame->size == 0 || !s_frame_queue)
        return;

    // Copy frame to queue buffer (thread-safe)
    if (xSemaphoreTake(s_queue_mutex, pdMS_TO_TICKS(5)) == pdTRUE)
    {
        size_t copy_size = frame->size;
        if (copy_size > sizeof(s_queue_buffer))
        {
            copy_size = sizeof(s_queue_buffer);
        }
        memcpy(s_queue_buffer, frame->data, copy_size);

        frame_msg_t msg = {
            .data = s_queue_buffer,
            .size = copy_size,
            .width = frame->width,
            .height = frame->height,
            .sequence = frame->sequence,
        };

        xSemaphoreGive(s_queue_mutex);

        // Non-blocking send
        xQueueOverwrite(s_frame_queue, &msg);
    }
}

static void camera_state_callback(usb_cam_state_t state, void *arg)
{
    if (state == USB_CAM_STATE_STREAMING)
    {
        ESP_LOGI(TAG, "CAM: Streaming started");
    }
    else if (state == USB_CAM_STATE_DISCONNECTED)
    {
        ESP_LOGW(TAG, "CAM: Disconnected");
    }
}

static void wifi_callback(wifi_ap_state_t state, void *arg)
{
    (void)state;
    (void)arg;
}
static void mavlink_heartbeat_callback(const mavlink_heartbeat_info_t *info, void *arg)
{
    (void)info;
    (void)arg;
}
static void rtsp_client_callback(uint32_t client_id, bool connected, void *arg)
{
    (void)client_id;
    (void)connected;
    (void)arg;
}

// ==================== NETWORK TASK (CPU1) ====================
static void network_task(void *arg)
{
    ESP_LOGI(TAG, "Network task started on CPU%d", xPortGetCoreID());

    // WiFi AP
    wifi_ap_set_callback(wifi_callback, NULL);
    wifi_ap_init();
    wifi_ap_start();
    ESP_LOGI(TAG, "WiFi: %s", WIFI_AP_SSID);

    // MAVLink
    mavlink_config_t mav_config = {
        .uart_num = MAVLINK_UART_NUM,
        .uart_tx_pin = MAVLINK_UART_TX_PIN,
        .uart_rx_pin = MAVLINK_UART_RX_PIN,
        .uart_baud = MAVLINK_UART_BAUD,
        .udp_port = MAVLINK_UDP_PORT,
        .on_heartbeat = mavlink_heartbeat_callback,
        .callback_arg = NULL,
    };
    mavlink_telemetry_init(&mav_config);
    mavlink_telemetry_start();
    ESP_LOGI(TAG, "MAVLink: UDP %d", MAVLINK_UDP_PORT);

    // RTSP Server
    rtsp_server_config_t rtsp_config = {
        .port = RTSP_PORT,
        .stream_name = RTSP_STREAM_NAME,
        .max_clients = RTSP_MAX_CLIENTS,
        .client_callback = rtsp_client_callback,
        .callback_arg = NULL,
    };
    rtsp_server_init(&rtsp_config);
    rtsp_server_start();
    ESP_LOGI(TAG, "RTSP: port %d", RTSP_PORT);

    // Frame queue -> RTSP
    frame_msg_t msg;
    uint32_t frame_count = 0;

    while (1)
    {
        if (xQueueReceive(s_frame_queue, &msg, pdMS_TO_TICKS(100)) == pdTRUE)
        {
            if (msg.size > 0)
            {
                rtsp_frame_t rtsp_frame = {
                    .data = msg.data,
                    .size = msg.size,
                    .capacity = msg.size,
                    .width = msg.width,
                    .height = msg.height,
                    .format = 0,
                    .timestamp = 0,
                    .sequence = msg.sequence,
                };
                rtsp_server_send_frame(&rtsp_frame);

                frame_count++;
                if (frame_count % 30 == 0)
                {
                    ESP_LOGI(TAG, "RTSP: sent frame #%lu (%u bytes)",
                             (unsigned long)frame_count, (unsigned)msg.size);
                }
            }
        }

        // Yield
        vTaskDelay(1);
    }
}

// ==================== CAMERA TASK (CPU0) ====================
static void camera_task(void *arg)
{
    ESP_LOGI(TAG, "Camera task started on CPU%d", xPortGetCoreID());

    // Biraz bekle - WiFi'nin başlaması için
    vTaskDelay(pdMS_TO_TICKS(2000));

    usb_cam_config_t cam_config = {
        .width = 640,
        .height = 480,
        .fps = 15,
        .format = USB_CAM_FORMAT_MJPEG,
        .frame_buffer_count = 1,
        .frame_callback = camera_frame_callback,
        .state_callback = camera_state_callback,
        .callback_arg = NULL,
    };

    esp_err_t ret = usb_camera_init(&cam_config);
    if (ret == ESP_OK)
    {
        usb_camera_start();
        ESP_LOGI(TAG, "CAM: Waiting for USB device on OTG port...");
    }
    else
    {
        ESP_LOGW(TAG, "CAM: init failed - %s", esp_err_to_name(ret));
    }

    // Periyodik durum kontrolü
    int count = 0;
    while (1)
    {
        vTaskDelay(pdMS_TO_TICKS(5000));
        count++;
        usb_cam_state_t state = usb_camera_get_state();
        if (state == USB_CAM_STATE_DISCONNECTED)
        {
            if (count % 6 == 0)
            { // Her 30 saniyede bir
                ESP_LOGW(TAG, "CAM: No USB camera detected. Plug into OTG port.");
            }
        }
    }
}

void app_main(void)
{
    // NVS
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        nvs_flash_erase();
        nvs_flash_init();
    }

    ESP_LOGI(TAG, "=== ESP32-S3 Camera RTSP System ===");
    ESP_LOGI(TAG, "Free heap: %lu", (unsigned long)esp_get_free_heap_size());

    // Frame queue ve mutex oluştur
    s_frame_queue = xQueueCreate(1, sizeof(frame_msg_t));
    s_queue_mutex = xSemaphoreCreateMutex();

    if (!s_frame_queue || !s_queue_mutex)
    {
        ESP_LOGE(TAG, "Failed to create queue/mutex");
        return;
    }

    // Network task - CPU1, yüksek priority
    xTaskCreatePinnedToCore(
        network_task,
        "network",
        8192,
        NULL,
        5, // Priority
        NULL,
        1 // CPU1
    );

    // Camera task - CPU0, orta priority
    xTaskCreatePinnedToCore(
        camera_task,
        "camera",
        4096,
        NULL,
        4, // Priority (network'ten düşük)
        NULL,
        0 // CPU0
    );

    // Main task bitti
    ESP_LOGI(TAG, "Tasks started, main exiting");
}